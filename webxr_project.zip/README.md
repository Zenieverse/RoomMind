
# WebXR Project

This is a minimal scaffolding for deployment on GitHub Pages.

## Deploy
- Push to repository
- Enable GitHub Pages
- Set branch: `main`
- Set folder: `/`
